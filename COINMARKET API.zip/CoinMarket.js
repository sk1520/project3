








$(document).ready(function(){



var $coinmarket= $('.order') ;

 	/*function refresh(){*/ $.ajax({
	type: 'GET',
	url: 'https://api.coinmarketcap.com/v1/ticker/',
	success: function(data){

		$.each(data, function(i,name){

			console.log('ho');
			$('#example').append('<tr>'+

				'<td>'+data[i].rank+ '</td>'+
				'<td>'+data[i].name+'</td>'+
				'<td>$ '+data[i].price_usd+'</td>'+
				'<td>'+data[i].percent_change_24h+'%</td>'+

				'</td');
		})
		//console.log('sucess',data);

	}
});
//}

//setTimeout('refresh()', 5000);



/*$.ajax({
	type: 'GET',
	url: 'https://api.coinmarketcap.com/v1/ticker/',
	success: function(data){

		$.each(data, function(i,name){
			$coinmarket.append('<li>NAME: '+data[i].id+ ' RANK: '+data[i].rank+ ' </li');
		})
		//console.log('sucess',data);

	}
});*/



});




/*$.getJSON("//api.coinmarketcap.com/v1/ticker/?limit=0", function(data) {

    var crypto = [
      "Ethereum",
      "Ripple",
      "Tron", 
    ];

    // used for array to get length
    var arrayLength = crypto.length;

    for (var i = 0; i < data.length; i++) {
        if(jQuery.inArray(data[i].name, crypto) !== -1)
            console.log('Finded: ' + data[i].name);
    }
  });










/*$.getJSON("https://api.coinmarketcap.com/v1/ticker/bitcoin", function(data){

var BTC= [
    {
        "id": "bitcoin",
        "name": "Bitcoin",
        "symbol": "BTC",
        "rank": "1",
        "price_usd": "573.137",
        "price_btc": "1.0",
        "24h_volume_usd": "72855700.0",
        "market_cap_usd": "9080883500.0",
        "available_supply": "15844176.0",
        "total_supply": "15844176.0",
        "max_supply": "21000000.0",
        "percent_change_1h": "0.04",
        "percent_change_24h": "-0.3",
        "percent_change_7d": "-0.57",
        "last_updated": "1472762067"
    }
]               

});*/



//});